var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// netlify/functions/google-auth.js
var require_google_auth = __commonJS({
  "netlify/functions/google-auth.js"(exports2, module2) {
    var crypto = require("crypto");
    async function getGoogleToken2(serviceAccountJson, scopes) {
      const sa = typeof serviceAccountJson === "string" ? JSON.parse(serviceAccountJson) : serviceAccountJson;
      const now = Math.floor(Date.now() / 1e3);
      const header = b64url(JSON.stringify({ alg: "RS256", typ: "JWT" }));
      const payload = b64url(JSON.stringify({
        iss: sa.client_email,
        scope: scopes.join(" "),
        aud: "https://oauth2.googleapis.com/token",
        iat: now,
        exp: now + 3600
      }));
      const signingInput = `${header}.${payload}`;
      const sign = crypto.createSign("RSA-SHA256");
      sign.update(signingInput);
      const signature = sign.sign(sa.private_key, "base64url");
      const jwt = `${signingInput}.${signature}`;
      const res = await fetch("https://oauth2.googleapis.com/token", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
          assertion: jwt
        })
      });
      if (!res.ok) {
        const text = await res.text();
        throw new Error(`Google token exchange failed (${res.status}): ${text}`);
      }
      const { access_token } = await res.json();
      return access_token;
    }
    function b64url(str) {
      return Buffer.from(str).toString("base64url");
    }
    async function getOAuthToken2(clientId, clientSecret, refreshToken) {
      const res = await fetch("https://oauth2.googleapis.com/token", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          grant_type: "refresh_token",
          refresh_token: refreshToken,
          client_id: clientId,
          client_secret: clientSecret
        })
      });
      if (!res.ok) {
        const text = await res.text();
        throw new Error(`OAuth token refresh failed (${res.status}): ${text}`);
      }
      const { access_token } = await res.json();
      return access_token;
    }
    module2.exports = { getGoogleToken: getGoogleToken2, getOAuthToken: getOAuthToken2 };
  }
});

// netlify/functions/fetch-gsc.js
var { getGoogleToken, getOAuthToken } = require_google_auth();
var SCOPES = ["https://www.googleapis.com/auth/webmasters.readonly"];
var BRAND_KEYWORDS = {
  HQ: [
    "brisbane",
    "teneriffe",
    "newstead",
    "physiotherap",
    "pilates",
    "pelvic",
    "womens health",
    "exercise physiologist",
    "rehabilitation",
    "group class",
    "lgbtqi",
    "neuro",
    "postnatal"
  ],
  Online: [
    "online",
    "powerlifting",
    "strength coach",
    "remote coaching",
    "strength program"
  ]
};
exports.handler = async () => {
  const siteUrl = process.env.GSC_SITE_URL;
  const clientId = process.env.GSC_CLIENT_ID;
  const clientSecret = process.env.GSC_CLIENT_SECRET;
  const refreshToken = process.env.GSC_REFRESH_TOKEN;
  const saKey = process.env.GOOGLE_SERVICE_ACCOUNT_KEY;
  if (!siteUrl) {
    return { statusCode: 503, body: JSON.stringify({ error: "GSC_SITE_URL must be set" }) };
  }
  if (!clientId && !saKey) {
    return { statusCode: 503, body: JSON.stringify({ error: "GSC_CLIENT_ID or GOOGLE_SERVICE_ACCOUNT_KEY must be set" }) };
  }
  try {
    const token = clientId && clientSecret && refreshToken ? await getOAuthToken(clientId, clientSecret, refreshToken) : await getGoogleToken(saKey, SCOPES);
    const encodedUrl = encodeURIComponent(siteUrl);
    const apiBase = `https://searchconsole.googleapis.com/webmasters/v3/sites/${encodedUrl}/searchAnalytics/query`;
    const today = fmtDate(/* @__PURE__ */ new Date());
    const d30ago = fmtDate(daysAgo(30));
    const d60ago = fmtDate(daysAgo(60));
    const d31ago = fmtDate(daysAgo(31));
    const d90ago = fmtDate(daysAgo(90));
    const [keywordReport, prevReport, dateReport] = await Promise.all([
      // Current 30-day keyword positions
      gscQuery(apiBase, token, {
        startDate: d30ago,
        endDate: today,
        dimensions: ["query"],
        rowLimit: 50,
        dataState: "final"
      }),
      // Prior 30-day window for position comparison
      gscQuery(apiBase, token, {
        startDate: d60ago,
        endDate: d31ago,
        dimensions: ["query"],
        rowLimit: 50,
        dataState: "final"
      }),
      // Daily data for the last 30 days (rank trend buckets)
      gscQuery(apiBase, token, {
        startDate: d30ago,
        endDate: today,
        dimensions: ["date", "query"],
        rowLimit: 5e3,
        dataState: "final"
      })
    ]);
    const prevPositionMap = {};
    for (const row of prevReport.rows || []) {
      prevPositionMap[row.keys[0]] = Math.round(row.position);
    }
    const keywords = (keywordReport.rows || []).map((row) => {
      const kw = row.keys[0];
      const current = Math.round(row.position);
      const prev = prevPositionMap[kw] || current;
      return {
        keyword: kw,
        brand: tagBrand(kw),
        current,
        previous: prev,
        volume: row.impressions
        // GSC impressions used as volume proxy
      };
    });
    const dateMap = {};
    for (const row of dateReport.rows || []) {
      const date = row.keys[0];
      const pos = row.position;
      if (!dateMap[date]) dateMap[date] = [];
      dateMap[date].push(pos);
    }
    const sortedDates = Object.keys(dateMap).sort();
    const labels = sortedDates;
    const buckets = {
      pos1_3: sortedDates.map((d) => dateMap[d].filter((p) => p <= 3).length),
      pos4_10: sortedDates.map((d) => dateMap[d].filter((p) => p > 3 && p <= 10).length),
      pos11_20: sortedDates.map((d) => dateMap[d].filter((p) => p > 10 && p <= 20).length),
      pos21_50: sortedDates.map((d) => dateMap[d].filter((p) => p > 20 && p <= 50).length),
      pos50plus: sortedDates.map((d) => dateMap[d].filter((p) => p > 50).length)
    };
    const seo = {
      connectionNote: `Google Search Console connected. Data covers ${d30ago} \u2013 ${today}.`,
      rankTrend30: { labels, ...buckets },
      keywords
    };
    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ seo })
    };
  } catch (err) {
    console.error("fetch-gsc error:", err);
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};
function tagBrand(keyword) {
  const kw = keyword.toLowerCase();
  const isHQ = BRAND_KEYWORDS.HQ.some((t) => kw.includes(t));
  const isOnline = BRAND_KEYWORDS.Online.some((t) => kw.includes(t));
  if (isHQ && isOnline) return "Both";
  if (isHQ) return "HQ";
  if (isOnline) return "Online";
  return "HQ";
}
async function gscQuery(url, token, body) {
  const res = await fetch(url, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  if (!res.ok) {
    const err = await res.text();
    throw new Error(`GSC query \u2192 HTTP ${res.status}: ${err}`);
  }
  return res.json();
}
function daysAgo(n) {
  const d = /* @__PURE__ */ new Date();
  d.setDate(d.getDate() - n);
  return d;
}
function fmtDate(d) {
  return d.toISOString().slice(0, 10);
}
