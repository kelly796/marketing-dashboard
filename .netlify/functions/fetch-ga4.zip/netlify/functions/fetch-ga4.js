var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// netlify/functions/google-auth.js
var require_google_auth = __commonJS({
  "netlify/functions/google-auth.js"(exports2, module2) {
    var crypto = require("crypto");
    async function getGoogleToken2(serviceAccountJson, scopes) {
      const sa = typeof serviceAccountJson === "string" ? JSON.parse(serviceAccountJson) : serviceAccountJson;
      const now = Math.floor(Date.now() / 1e3);
      const header = b64url(JSON.stringify({ alg: "RS256", typ: "JWT" }));
      const payload = b64url(JSON.stringify({
        iss: sa.client_email,
        scope: scopes.join(" "),
        aud: "https://oauth2.googleapis.com/token",
        iat: now,
        exp: now + 3600
      }));
      const signingInput = `${header}.${payload}`;
      const sign = crypto.createSign("RSA-SHA256");
      sign.update(signingInput);
      const signature = sign.sign(sa.private_key, "base64url");
      const jwt = `${signingInput}.${signature}`;
      const res = await fetch("https://oauth2.googleapis.com/token", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
          assertion: jwt
        })
      });
      if (!res.ok) {
        const text = await res.text();
        throw new Error(`Google token exchange failed (${res.status}): ${text}`);
      }
      const { access_token } = await res.json();
      return access_token;
    }
    function b64url(str) {
      return Buffer.from(str).toString("base64url");
    }
    async function getOAuthToken(clientId, clientSecret, refreshToken) {
      const res = await fetch("https://oauth2.googleapis.com/token", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          grant_type: "refresh_token",
          refresh_token: refreshToken,
          client_id: clientId,
          client_secret: clientSecret
        })
      });
      if (!res.ok) {
        const text = await res.text();
        throw new Error(`OAuth token refresh failed (${res.status}): ${text}`);
      }
      const { access_token } = await res.json();
      return access_token;
    }
    module2.exports = { getGoogleToken: getGoogleToken2, getOAuthToken };
  }
});

// netlify/functions/fetch-ga4.js
var { getGoogleToken } = require_google_auth();
var SCOPES = ["https://www.googleapis.com/auth/analytics.readonly"];
exports.handler = async () => {
  const propertyId = process.env.GA4_PROPERTY_ID;
  const saKey = process.env.GOOGLE_SERVICE_ACCOUNT_KEY;
  if (!propertyId || !saKey) {
    return {
      statusCode: 503,
      body: JSON.stringify({ error: "GA4_PROPERTY_ID and GOOGLE_SERVICE_ACCOUNT_KEY must be set" })
    };
  }
  try {
    const token = await getGoogleToken(saKey, SCOPES);
    const base = `https://analyticsdata.googleapis.com/v1beta/properties/${propertyId}`;
    const [countryReport, summaryReport, sourceReport, pagesReport] = await Promise.all([
      // Country breakdown for the last 30 days
      runReport(base, token, {
        dateRanges: [{ startDate: "30daysAgo", endDate: "today" }],
        dimensions: [{ name: "country" }],
        metrics: [
          { name: "sessions" },
          { name: "screenPageViewsPerSession" },
          { name: "conversions" }
        ],
        orderBys: [{ metric: { metricName: "sessions" }, desc: true }],
        limit: 10
      }),
      // Overall totals — current and prior 30-day window for comparison
      runReport(base, token, {
        dateRanges: [
          { startDate: "30daysAgo", endDate: "today" },
          { startDate: "60daysAgo", endDate: "31daysAgo" }
        ],
        metrics: [
          { name: "sessions" },
          { name: "activeUsers" },
          { name: "conversions" },
          { name: "screenPageViewsPerSession" }
        ]
      }),
      // Top channel per country (for source attribution)
      runReport(base, token, {
        dateRanges: [{ startDate: "30daysAgo", endDate: "today" }],
        dimensions: [
          { name: "country" },
          { name: "sessionDefaultChannelGroup" }
        ],
        metrics: [{ name: "sessions" }],
        orderBys: [{ metric: { metricName: "sessions" }, desc: true }],
        limit: 50
      }),
      // Top pages by sessions for the last 30 days
      runReport(base, token, {
        dateRanges: [{ startDate: "30daysAgo", endDate: "today" }],
        dimensions: [{ name: "pagePath" }, { name: "pageTitle" }],
        metrics: [
          { name: "sessions" },
          { name: "screenPageViews" },
          { name: "activeUsers" }
        ],
        orderBys: [{ metric: { metricName: "sessions" }, desc: true }],
        limit: 10
      })
    ]);
    const topSource = {};
    for (const row of sourceReport.rows || []) {
      const country = row.dimensionValues[0].value;
      if (!topSource[country]) topSource[country] = row.dimensionValues[1].value;
    }
    const ga4Countries = (countryReport.rows || []).map((row) => {
      const country = row.dimensionValues[0].value;
      const sessions2 = Number(row.metricValues[0].value);
      const pages = +Number(row.metricValues[1].value).toFixed(1);
      const convRate = sessions2 ? +(Number(row.metricValues[2].value) / sessions2 * 100).toFixed(1) : 0;
      return {
        country,
        sessions: sessions2,
        pages,
        convRate,
        products: 0,
        // requires ecommerce purchase events
        source: topSource[country] || "Organic Search"
      };
    });
    const rows = summaryReport.rows || [];
    const getMetric = (rowIndex, metricIndex) => rows[rowIndex] ? Number(rows[rowIndex].metricValues[metricIndex].value) : 0;
    const sessions = getMetric(0, 0);
    const sessionsPrev = getMetric(1, 0) || Math.round(sessions * 0.92);
    const activeUsers = getMetric(0, 1);
    const conversions = getMetric(0, 2);
    const pagesPerSession = rows[0] ? +Number(rows[0].metricValues[3].value).toFixed(1) : 0;
    const ga4 = {
      sessions,
      sessionsPrev,
      activeUsers,
      users: activeUsers,
      conversions,
      conversionRate: sessions ? +(conversions / sessions * 100).toFixed(1) : 0,
      pagesPerSession
    };
    const ga4TopPages = (pagesReport.rows || []).map((row) => ({
      page: row.dimensionValues[0].value,
      title: row.dimensionValues[1].value || row.dimensionValues[0].value,
      sessions: Number(row.metricValues[0].value),
      views: Number(row.metricValues[1].value),
      activeUsers: Number(row.metricValues[2].value)
    }));
    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ga4, ga4Countries, ga4TopPages })
    };
  } catch (err) {
    console.error("fetch-ga4 error:", err);
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};
async function runReport(base, token, body) {
  const res = await fetch(`${base}:runReport`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  if (!res.ok) {
    const err = await res.text();
    throw new Error(`GA4 runReport \u2192 HTTP ${res.status}: ${err}`);
  }
  return res.json();
}
