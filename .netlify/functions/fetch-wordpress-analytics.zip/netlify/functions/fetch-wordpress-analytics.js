// netlify/functions/fetch-wordpress-analytics.js
exports.handler = async () => {
  const siteUrl = (process.env.WP_SITE_URL || "").replace(/\/$/, "");
  const username = process.env.WP_USERNAME;
  const appPassword = process.env.WP_APP_PASSWORD;
  if (!siteUrl || !username || !appPassword) {
    return {
      statusCode: 503,
      body: JSON.stringify({ error: "WP_SITE_URL, WP_USERNAME and WP_APP_PASSWORD must all be set" })
    };
  }
  const credentials = Buffer.from(`${username}:${appPassword}`).toString("base64");
  try {
    const res = await fetch(`${siteUrl}/wp-json/performotion/v1/analytics`, {
      headers: {
        Authorization: `Basic ${credentials}`,
        Accept: "application/json",
        "Content-Type": "application/json"
      }
    });
    if (res.status === 401) {
      throw new Error("WordPress authentication failed \u2014 check WP_USERNAME and WP_APP_PASSWORD");
    }
    if (res.status === 404) {
      throw new Error("WordPress analytics endpoint not found \u2014 confirm performotion-analytics.php is in /wp-content/mu-plugins/");
    }
    if (!res.ok) {
      const text = await res.text();
      throw new Error(`WordPress analytics \u2192 HTTP ${res.status}: ${text.slice(0, 200)}`);
    }
    const data = await res.json();
    if (data.code && data.message) {
      throw new Error(`WordPress REST error: ${data.message}`);
    }
    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ wpAnalytics: data })
    };
  } catch (err) {
    console.error("fetch-wordpress-analytics error:", err.message);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err.message })
    };
  }
};
