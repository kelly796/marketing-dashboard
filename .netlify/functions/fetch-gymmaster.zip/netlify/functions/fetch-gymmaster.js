// netlify/functions/fetch-gymmaster.js
var GM_BASE = "https://performotion.gymmasteronline.com/portal/api";
exports.handler = async () => {
  const apiKey = process.env.GYMMASTER_API_KEY;
  if (!apiKey) {
    return {
      statusCode: 503,
      body: JSON.stringify({ error: "GYMMASTER_API_KEY env var not set" })
    };
  }
  try {
    const membersData = await gmGet("/members", apiKey);
    const now = Date.now();
    const d30 = now - 30 * 24 * 60 * 60 * 1e3;
    const d60 = now - 60 * 24 * 60 * 60 * 1e3;
    const allMembers = membersData.members || membersData || [];
    const activeMembers = allMembers.filter((m) => m.status === "active" || m.memberStatus === "Active");
    const holdMembers = allMembers.filter((m) => m.status === "hold" || m.memberStatus === "Hold");
    const newMembers30d = allMembers.filter((m) => m.status === "active" && new Date(m.joinDate || m.startDate).getTime() > d30);
    const churnedMembers = allMembers.filter((m) => (m.status === "cancelled" || m.memberStatus === "Cancelled") && new Date(m.endDate || m.cancelDate).getTime() > d30);
    const prevActive = allMembers.filter((m) => {
      const joined = new Date(m.joinDate || m.startDate).getTime();
      return joined < d30;
    });
    const prevNewMembers = allMembers.filter((m) => {
      const joined = new Date(m.joinDate || m.startDate).getTime();
      return joined > d60 && joined <= d30;
    });
    const prevChurned = allMembers.filter((m) => {
      const ended = new Date(m.endDate || m.cancelDate).getTime();
      return ended > d60 && ended <= d30;
    });
    const prevHold = holdMembers;
    const totalActive = activeMembers.length;
    const totalChurned = churnedMembers.length;
    const retentionRate = totalActive + totalChurned > 0 ? +(totalActive / (totalActive + totalChurned) * 100).toFixed(1) : 100;
    const prevRetention = prevActive.length + prevChurned.length > 0 ? +(prevActive.length / (prevActive.length + prevChurned.length) * 100).toFixed(1) : 100;
    const COLOURS = ["#2ABFBF", "#1B2A4A", "#D4B896", "#94a3b8", "#10B981", "#f59e0b"];
    const typeCounts = {};
    for (const m of activeMembers) {
      const t = m.membershipType || m.membership || "Other";
      typeCounts[t] = (typeCounts[t] || 0) + 1;
    }
    const membershipTypes = Object.entries(typeCounts).sort((a, b) => b[1] - a[1]).map(([name, count], i) => ({
      name,
      count,
      pct: totalActive ? Math.round(count / totalActive * 100) : 0,
      colour: COLOURS[i % COLOURS.length]
    }));
    const atRiskList = [];
    const membersWithDuration = allMembers.filter((m) => m.joinDate || m.startDate);
    const avgMemberLifetime = membersWithDuration.length ? Math.round(
      membersWithDuration.reduce((s, m) => {
        const start = new Date(m.joinDate || m.startDate).getTime();
        const end = m.endDate ? new Date(m.endDate).getTime() : now;
        return s + (end - start) / (30 * 24 * 60 * 60 * 1e3);
      }, 0) / membersWithDuration.length
    ) : 0;
    const growthTrend = Array.from({ length: 6 }, (_, i) => {
      const monthStart = new Date(now);
      monthStart.setMonth(monthStart.getMonth() - (5 - i));
      monthStart.setDate(1);
      monthStart.setHours(0, 0, 0, 0);
      const monthEnd = new Date(monthStart);
      monthEnd.setMonth(monthEnd.getMonth() + 1);
      return allMembers.filter((m) => {
        const joined = new Date(m.joinDate || m.startDate).getTime();
        const left = m.endDate ? new Date(m.endDate).getTime() : Infinity;
        return joined <= monthEnd.getTime() && left >= monthStart.getTime();
      }).length;
    });
    const reasonCounts = {};
    for (const m of churnedMembers) {
      const r = m.cancellationReason || m.cancelReason || "Other";
      reasonCounts[r] = (reasonCounts[r] || 0) + 1;
    }
    const totalCancellations = Object.values(reasonCounts).reduce((s, n) => s + n, 0) || 1;
    const cancellationReasons = Object.entries(reasonCounts).sort((a, b) => b[1] - a[1]).slice(0, 6).map(([reason, count]) => ({ reason, pct: Math.round(count / totalCancellations * 100) }));
    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        activeMembers: totalActive,
        activeMembersPrev: prevActive.length,
        membersOnHold: holdMembers.length,
        membersOnHoldPrev: prevHold.length,
        newMembers30d: newMembers30d.length,
        newMembers30dPrev: prevNewMembers.length,
        churnedMembers30d: totalChurned,
        churnedMembers30dPrev: prevChurned.length,
        atRiskMembers: atRiskList.length,
        avgMemberLifetime,
        retentionRate,
        retentionRatePrev: prevRetention,
        membershipRevenue: 0,
        membershipRevenuePrev: 0,
        overdueRevenue: 0,
        overdueCount: 0,
        renewalsThisWeek: 0,
        growthTrend,
        membershipTypes,
        cancellationReasons: cancellationReasons.length ? cancellationReasons : [{ reason: "No data", pct: 100 }],
        atRiskList
      })
    };
  } catch (err) {
    console.error("fetch-gymmaster error:", err);
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};
async function gmGet(path, apiKey, retries = 3) {
  for (let attempt = 0; attempt < retries; attempt++) {
    const res = await fetch(`${GM_BASE}${path}?key=${encodeURIComponent(apiKey)}`);
    if (res.status === 429) {
      await new Promise((r) => setTimeout(r, 1e3 * (attempt + 1)));
      continue;
    }
    if (!res.ok) throw new Error(`GymMaster API ${path} returned ${res.status}`);
    return res.json();
  }
  throw new Error(`GymMaster API ${path} failed after ${retries} retries`);
}
