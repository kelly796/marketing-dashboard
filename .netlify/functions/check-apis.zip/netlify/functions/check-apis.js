var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// netlify/functions/google-auth.js
var require_google_auth = __commonJS({
  "netlify/functions/google-auth.js"(exports2, module2) {
    var crypto = require("crypto");
    async function getGoogleToken2(serviceAccountJson, scopes) {
      const sa = typeof serviceAccountJson === "string" ? JSON.parse(serviceAccountJson) : serviceAccountJson;
      const now = Math.floor(Date.now() / 1e3);
      const header = b64url(JSON.stringify({ alg: "RS256", typ: "JWT" }));
      const payload = b64url(JSON.stringify({
        iss: sa.client_email,
        scope: scopes.join(" "),
        aud: "https://oauth2.googleapis.com/token",
        iat: now,
        exp: now + 3600
      }));
      const signingInput = `${header}.${payload}`;
      const sign = crypto.createSign("RSA-SHA256");
      sign.update(signingInput);
      const signature = sign.sign(sa.private_key, "base64url");
      const jwt = `${signingInput}.${signature}`;
      const res = await fetch("https://oauth2.googleapis.com/token", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
          assertion: jwt
        })
      });
      if (!res.ok) {
        const text = await res.text();
        throw new Error(`Google token exchange failed (${res.status}): ${text}`);
      }
      const { access_token } = await res.json();
      return access_token;
    }
    function b64url(str) {
      return Buffer.from(str).toString("base64url");
    }
    async function getOAuthToken2(clientId, clientSecret, refreshToken) {
      const res = await fetch("https://oauth2.googleapis.com/token", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          grant_type: "refresh_token",
          refresh_token: refreshToken,
          client_id: clientId,
          client_secret: clientSecret
        })
      });
      if (!res.ok) {
        const text = await res.text();
        throw new Error(`OAuth token refresh failed (${res.status}): ${text}`);
      }
      const { access_token } = await res.json();
      return access_token;
    }
    module2.exports = { getGoogleToken: getGoogleToken2, getOAuthToken: getOAuthToken2 };
  }
});

// netlify/functions/check-apis.js
var { getGoogleToken, getOAuthToken } = require_google_auth();
exports.handler = async () => {
  const results = {};
  await Promise.all([
    checkMeta(results),
    checkYouTube(results),
    checkGA4(results),
    checkGSC(results),
    checkAC(results)
  ]);
  return {
    statusCode: 200,
    headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
    body: JSON.stringify(results, null, 2)
  };
};
async function checkMeta(out) {
  const token = process.env.META_ACCESS_TOKEN;
  const hqPageId = process.env.META_HQ_PAGE_ID;
  const onPageId = process.env.META_ONLINE_PAGE_ID;
  const adAcctId = process.env.META_AD_ACCOUNT_ID;
  if (!token) {
    out.meta = { ok: false, error: "META_ACCESS_TOKEN not set" };
    return;
  }
  try {
    const me = await metaGet("/me", { fields: "id,name", access_token: token });
    const igHqId = hqPageId ? (await metaGet(`/${hqPageId}`, { fields: "instagram_business_account,name", access_token: token }))?.instagram_business_account?.id : null;
    const igOnId = onPageId ? (await metaGet(`/${onPageId}`, { fields: "instagram_business_account,name", access_token: token }).catch(() => null))?.instagram_business_account?.id : null;
    out.meta = {
      ok: true,
      tokenUser: me.name || me.id,
      hqPageId: hqPageId || "NOT SET",
      igHqAccountId: igHqId || "not found \u2014 check META_HQ_PAGE_ID",
      onlinePageId: onPageId || "NOT SET \u2014 add META_ONLINE_PAGE_ID to connect @performotion_online",
      igOnlineAccountId: igOnId || (onPageId ? "not found \u2014 check META_ONLINE_PAGE_ID" : "not set"),
      adAccountId: adAcctId || "NOT SET"
    };
  } catch (e) {
    out.meta = { ok: false, error: e.message };
  }
}
async function checkYouTube(out) {
  const apiKey = process.env.YOUTUBE_API_KEY;
  const channelId = process.env.YOUTUBE_CHANNEL_ID;
  if (!apiKey) {
    out.youtube = { ok: false, error: "YOUTUBE_API_KEY not set" };
    return;
  }
  if (!channelId) {
    out.youtube = { ok: false, error: "YOUTUBE_CHANNEL_ID not set" };
    return;
  }
  try {
    let resolvedId = channelId;
    if (channelId.startsWith("@") || !channelId.startsWith("UC")) {
      const handle = channelId.replace(/^@/, "");
      const res2 = await ytGet("/channels", { part: "id", forHandle: handle, key: apiKey });
      resolvedId = (res2.items || [])[0]?.id;
      if (!resolvedId) throw new Error(`Handle @${handle} not found \u2014 check YOUTUBE_CHANNEL_ID`);
    }
    const res = await ytGet("/channels", { part: "statistics,snippet", id: resolvedId, key: apiKey });
    const item = (res.items || [])[0];
    if (!item) throw new Error(`Channel ID ${resolvedId} not found \u2014 check YOUTUBE_CHANNEL_ID`);
    out.youtube = {
      ok: true,
      channelId: resolvedId,
      title: item.snippet?.title,
      subscribers: item.statistics?.subscriberCount,
      videos: item.statistics?.videoCount
    };
  } catch (e) {
    out.youtube = { ok: false, error: e.message };
  }
}
async function checkGA4(out) {
  const propertyId = process.env.GA4_PROPERTY_ID;
  const saKey = process.env.GOOGLE_SERVICE_ACCOUNT_KEY;
  if (!propertyId) {
    out.ga4 = { ok: false, error: "GA4_PROPERTY_ID not set" };
    return;
  }
  if (!saKey) {
    out.ga4 = { ok: false, error: "GOOGLE_SERVICE_ACCOUNT_KEY not set" };
    return;
  }
  try {
    const sa = JSON.parse(saKey);
    const token = await getGoogleToken(saKey, ["https://www.googleapis.com/auth/analytics.readonly"]);
    const res = await fetch(
      `https://analyticsdata.googleapis.com/v1beta/properties/${propertyId}:runReport`,
      {
        method: "POST",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          dateRanges: [{ startDate: "7daysAgo", endDate: "today" }],
          metrics: [{ name: "sessions" }]
        })
      }
    );
    if (!res.ok) {
      const err = await res.text();
      throw new Error(`GA4 API ${res.status}: ${err.slice(0, 300)}`);
    }
    const data = await res.json();
    out.ga4 = {
      ok: true,
      propertyId,
      serviceAccount: sa.client_email,
      sessions7d: data.rows?.[0]?.metricValues?.[0]?.value || "0"
    };
  } catch (e) {
    out.ga4 = { ok: false, error: e.message };
  }
}
async function checkGSC(out) {
  const siteUrl = process.env.GSC_SITE_URL;
  const clientId = process.env.GSC_CLIENT_ID;
  const clientSecret = process.env.GSC_CLIENT_SECRET;
  const refreshToken = process.env.GSC_REFRESH_TOKEN;
  const saKey = process.env.GOOGLE_SERVICE_ACCOUNT_KEY;
  if (!siteUrl) {
    out.gsc = { ok: false, error: "GSC_SITE_URL not set" };
    return;
  }
  if (!clientId && !saKey) {
    out.gsc = { ok: false, error: "GSC_CLIENT_ID or GOOGLE_SERVICE_ACCOUNT_KEY not set" };
    return;
  }
  try {
    const token = clientId && clientSecret && refreshToken ? await getOAuthToken(clientId, clientSecret, refreshToken) : await getGoogleToken(saKey, ["https://www.googleapis.com/auth/webmasters.readonly"]);
    const encodedUrl = encodeURIComponent(siteUrl);
    const res = await fetch(
      `https://searchconsole.googleapis.com/webmasters/v3/sites/${encodedUrl}/searchAnalytics/query`,
      {
        method: "POST",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          startDate: new Date(Date.now() - 7 * 864e5).toISOString().slice(0, 10),
          endDate: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
          rowLimit: 1
        })
      }
    );
    if (!res.ok) {
      const err = await res.text();
      throw new Error(`GSC API ${res.status}: ${err.slice(0, 300)}`);
    }
    const data = await res.json();
    out.gsc = {
      ok: true,
      siteUrl,
      clicks7d: data.rows?.[0]?.clicks || 0
    };
  } catch (e) {
    out.gsc = { ok: false, error: e.message };
  }
}
async function checkAC(out) {
  const key = process.env.AC_API_KEY;
  const baseUrl = process.env.AC_BASE_URL;
  if (!key || !baseUrl) {
    out.activecampaign = { ok: false, error: "AC_API_KEY or AC_BASE_URL not set" };
    return;
  }
  try {
    const res = await fetch(`${baseUrl.replace(/\/$/, "")}/api/3/contacts?limit=1`, {
      headers: { "Api-Token": key }
    });
    if (!res.ok) throw new Error(`AC API ${res.status}`);
    const data = await res.json();
    out.activecampaign = { ok: true, totalContacts: data.meta?.total || "unknown" };
  } catch (e) {
    out.activecampaign = { ok: false, error: e.message };
  }
}
async function metaGet(path, params) {
  const qs = new URLSearchParams(Object.fromEntries(Object.entries(params).map(([k, v]) => [k, String(v)]))).toString();
  const res = await fetch(`https://graph.facebook.com/v19.0${path}?${qs}`);
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body?.error?.message || `Meta API HTTP ${res.status}`);
  }
  return res.json();
}
async function ytGet(path, params) {
  const res = await fetch(`https://www.googleapis.com/youtube/v3${path}?` + new URLSearchParams(params));
  if (!res.ok) {
    const err = await res.text();
    throw new Error(`YouTube API ${res.status}: ${err.slice(0, 200)}`);
  }
  return res.json();
}
