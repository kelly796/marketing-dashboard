// netlify/functions/ac-wordpress-sync.js
var crypto = require("crypto");
exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }
  const signature = event.headers["x-ac-signature"] || event.headers["x-webhook-token"] || "";
  const secret = process.env.AC_WEBHOOK_TOKEN || "";
  if (!verifySignature(event.body, signature, secret)) {
    console.warn("Webhook signature mismatch \u2014 request rejected");
    return { statusCode: 401, body: "Unauthorized" };
  }
  let payload;
  try {
    payload = event.headers["content-type"]?.includes("application/json") ? JSON.parse(event.body) : Object.fromEntries(new URLSearchParams(event.body));
  } catch (err) {
    return { statusCode: 400, body: "Invalid payload" };
  }
  const eventType = payload.type || payload["type[0]"] || "";
  try {
    if (eventType === "click" || eventType === "link_click") {
      await handleClick(payload);
    } else if (eventType === "open") {
      console.log(`Open: contact ${payload.contact_email} / campaign ${payload.campaign_id}`);
    } else if (eventType === "unsubscribe") {
      console.log(`Unsubscribe: ${payload.contact_email} from list ${payload.list_name}`);
    }
    return { statusCode: 200, body: JSON.stringify({ ok: true, type: eventType }) };
  } catch (err) {
    console.error("Handler error:", err);
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};
async function handleClick(payload) {
  const clickedUrl = payload.url || payload["url[0]"] || "";
  if (!clickedUrl.includes("performotion.net")) {
    console.log(`Ignored click to external URL: ${clickedUrl}`);
    return;
  }
  const click = {
    contactEmail: payload.contact_email || payload["contact[email]"] || "",
    contactId: payload.contact_id || payload["contact[id]"] || "",
    campaignId: payload.campaign_id || payload["campaign[id]"] || "",
    campaignName: payload.campaign_name || payload["campaign[name]"] || "email",
    listId: payload.list_id || payload["list[id]"] || "",
    listName: payload.list_name || payload["list[name]"] || "",
    clickedUrl,
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  };
  const [ga4Result, wpResult] = await Promise.allSettled([
    sendGA4Event(click),
    postToWordPress(click)
  ]);
  if (ga4Result.status === "rejected") console.error("GA4 error:", ga4Result.reason);
  if (wpResult.status === "rejected") console.error("WP error:", wpResult.reason);
  console.log(`Click tracked: ${click.contactEmail} \u2192 ${click.clickedUrl} [campaign: ${click.campaignName}]`);
}
async function sendGA4Event(click) {
  const measurementId = process.env.GA4_MEASUREMENT_ID;
  const apiSecret = process.env.GA4_API_SECRET;
  if (!measurementId || !apiSecret) {
    console.warn("GA4 env vars not set \u2014 skipping GA4 event");
    return;
  }
  const clientId = click.contactId ? `ac_${click.contactId}` : `ac_anon_${Date.now()}`;
  const body = JSON.stringify({
    client_id: clientId,
    timestamp_micros: Date.now() * 1e3,
    events: [{
      name: "email_click_to_website",
      params: {
        // Traffic source attribution
        source: "email",
        medium: "newsletter",
        campaign: slugify(click.campaignName),
        content: slugify(click.listName),
        // Event-specific data
        campaign_id: click.campaignId,
        list_id: click.listId,
        list_name: click.listName,
        clicked_url: click.clickedUrl,
        // Page context
        page_location: click.clickedUrl,
        engagement_time_msec: 1
      }
    }]
  });
  const res = await fetch(
    `https://www.google-analytics.com/mp/collect?measurement_id=${measurementId}&api_secret=${apiSecret}`,
    { method: "POST", headers: { "Content-Type": "application/json" }, body }
  );
  if (res.status !== 204 && res.status !== 200) {
    const text = await res.text();
    throw new Error(`GA4 returned ${res.status}: ${text}`);
  }
}
async function postToWordPress(click) {
  const siteUrl = process.env.WP_SITE_URL;
  const username = process.env.WP_USERNAME;
  const appPassword = process.env.WP_APP_PASSWORD;
  if (!siteUrl || !username || !appPassword) {
    console.warn("WordPress env vars not set \u2014 skipping WP write");
    return;
  }
  const credentials = Buffer.from(`${username}:${appPassword}`).toString("base64");
  const res = await fetch(`${siteUrl}/wp-json/performotion/v1/email-click`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Basic ${credentials}`
    },
    body: JSON.stringify({
      contact_email: click.contactEmail,
      campaign_id: click.campaignId,
      campaign_name: click.campaignName,
      list_id: click.listId,
      list_name: click.listName,
      clicked_url: click.clickedUrl,
      timestamp: click.timestamp,
      utm_source: "email",
      utm_medium: "newsletter",
      utm_campaign: slugify(click.campaignName)
    })
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`WordPress returned ${res.status}: ${text}`);
  }
}
function verifySignature(body, signature, secret) {
  if (!secret) {
    console.error("SECURITY: AC_WEBHOOK_TOKEN is not configured. All webhook requests are being rejected. Set this env var in Netlify immediately.");
    return false;
  }
  if (signature === secret) return true;
  try {
    const expected = crypto.createHmac("sha256", secret).update(body).digest("hex");
    return crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected));
  } catch {
    return false;
  }
}
function slugify(str) {
  return (str || "").toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "");
}
