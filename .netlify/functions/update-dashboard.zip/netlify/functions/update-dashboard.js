var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// netlify/functions/fetch-activecampaign.js
var require_fetch_activecampaign = __commonJS({
  "netlify/functions/fetch-activecampaign.js"(exports2) {
    var MONTH_NAMES = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    exports2.handler = async () => {
      const base = (process.env.AC_BASE_URL || "").replace(/\/$/, "");
      const apiKey = process.env.AC_API_KEY;
      if (!base || !apiKey) {
        return {
          statusCode: 503,
          body: JSON.stringify({ error: "AC_BASE_URL and AC_API_KEY env vars must be set" })
        };
      }
      const headers = { "Api-Token": apiKey, "Content-Type": "application/json" };
      try {
        const [allListsData, contactsData] = await Promise.all([
          acGet(base, "/api/3/lists?limit=100&orders[name]=ASC", headers),
          acGet(base, "/api/3/contacts?limit=1", headers)
        ]);
        const allACLists = allListsData.lists || [];
        const totalContacts = Number(contactsData.meta?.total || 0);
        const trackedIds = allACLists.map((l) => String(l.id));
        const hqIds = allACLists.filter((l) => /\[HQ\]/i.test(l.name)).map((l) => String(l.id));
        const onlineIds = allACLists.filter((l) => /\[Online\]/i.test(l.name)).map((l) => String(l.id));
        const otherIds = trackedIds.filter((id) => !hqIds.includes(id) && !onlineIds.includes(id));
        const listNameMap = {};
        allACLists.forEach((l) => {
          listNameMap[String(l.id)] = l.name;
        });
        const perListCampPromises = trackedIds.map(
          (id) => acGet(base, `/api/3/campaigns?filters[listid]=${id}&filters[status]=5&orders[sdate]=DESC&limit=5`, headers)
        );
        const perListCountPromises = trackedIds.map(
          (id) => acGet(base, `/api/3/contacts?listid=${id}&status=1&limit=0`, headers)
        );
        const [allCampaignsData, automationsData, ...parallelResults] = await Promise.all([
          acGet(base, "/api/3/campaigns?filters[status]=5&orders[sdate]=DESC&limit=100", headers),
          acGet(base, "/api/3/automations?filters[status]=1&limit=100", headers),
          ...perListCampPromises,
          ...perListCountPromises
        ]);
        const campResults = parallelResults.slice(0, trackedIds.length);
        const countResults = parallelResults.slice(trackedIds.length);
        const listCampaignMap = {};
        const listCountMap = {};
        trackedIds.forEach((id, i) => {
          listCampaignMap[id] = campResults[i];
          listCountMap[id] = Number(countResults[i]?.meta?.total || 0);
        });
        const allCampaigns = allCampaignsData.campaigns || [];
        const allAutomations = automationsData.automations || [];
        const hq = buildBrandData(hqIds, listNameMap, listCampaignMap, listCountMap, allCampaigns, allAutomations);
        const online = buildBrandData(onlineIds, listNameMap, listCampaignMap, listCountMap, allCampaigns, allAutomations);
        const other = buildBrandData(otherIds, listNameMap, listCampaignMap, listCountMap, allCampaigns, allAutomations);
        const overall = buildOverallStats(totalContacts, allCampaigns);
        const accountLists = allACLists.map((l) => {
          const id = String(l.id);
          return {
            id,
            name: l.name,
            subscribers: trackedIds.includes(id) ? listCountMap[id] || 0 : Number(l.subscriber_count || 0),
            created: (l.cdate || "").slice(0, 10),
            isTarget: trackedIds.includes(id),
            brand: hqIds.includes(id) ? "HQ" : onlineIds.includes(id) ? "Online" : null
          };
        });
        return {
          statusCode: 200,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ overall, hq, online, other, allLists: accountLists })
        };
      } catch (err) {
        console.error("fetch-activecampaign error:", err);
        return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
      }
    };
    function buildBrandData(listIds, listNameMap, listCampaignMap, listCountMap, allCampaigns, allAutomations) {
      const now = Date.now();
      const d30 = now - 30 * 24 * 60 * 60 * 1e3;
      const d60 = now - 60 * 24 * 60 * 60 * 1e3;
      const listIdSet = new Set(listIds);
      const brandCampaignsForTrend = allCampaigns.filter(
        (c) => (c.lists || []).map(String).some((id) => listIdSet.has(id))
      );
      let totalSubscribers = 0;
      const seenCampaignIds = /* @__PURE__ */ new Set();
      const mergedCampaignRows = [];
      const lists = listIds.map((id) => {
        const campsResp = listCampaignMap[id] || {};
        const campaigns2 = campsResp.campaigns || [];
        const subscribers = listCountMap[id] !== void 0 ? listCountMap[id] : 0;
        totalSubscribers += subscribers;
        const lstStats = aggregateCampaignStats(campaigns2);
        const lastCamp = campaigns2[0];
        for (const c of campaigns2) {
          if (!seenCampaignIds.has(c.id)) {
            seenCampaignIds.add(c.id);
            mergedCampaignRows.push(c);
          }
        }
        const listTrendCamps = brandCampaignsForTrend.filter(
          (c) => (c.lists || []).map(String).includes(id)
        );
        const lstBuckets = buildMonthlyBuckets(listTrendCamps, 6);
        return {
          id,
          name: listNameMap[id] || `List ${id}`,
          subscribers,
          openRate: lstStats.openRate,
          clickRate: lstStats.clickRate,
          clickToWebsiteRate: 0,
          lastCampaign: lastCamp ? { name: lastCamp.name, sent: (lastCamp.sdate || "").slice(0, 10) } : { name: "\u2014", sent: "\u2014" },
          engagementTrend: lstBuckets.map((b) => b.openRate),
          sequences: []
        };
      });
      const campaigns = mergedCampaignRows.sort((a, b) => new Date(b.sdate) - new Date(a.sdate)).slice(0, 5).map((c) => {
        const sent = Number(c.sendamt || 0);
        const opens = Number(c.uniqueopens || 0);
        const clicks = Number(c.subscriberclicks || 0);
        const unsubs = Number(c.unsubscribes || 0);
        return {
          name: c.name,
          date: (c.sdate || "").slice(0, 10),
          sent,
          opens,
          clicks,
          unsubs,
          openRate: sent ? +(opens / sent * 100).toFixed(1) : 0,
          clickRate: sent ? +(clicks / sent * 100).toFixed(1) : 0
        };
      });
      const recentCamps = brandCampaignsForTrend.filter((c) => new Date(c.sdate).getTime() > d30);
      const prevCamps = brandCampaignsForTrend.filter((c) => {
        const t = new Date(c.sdate).getTime();
        return t > d60 && t <= d30;
      });
      const aggStats = aggregateCampaignStats(recentCamps);
      const prevStats = aggregateCampaignStats(prevCamps);
      const recentUnsubs = recentCamps.reduce((s, c) => s + Number(c.unsubscribes || 0), 0);
      const prevUnsubs = prevCamps.reduce((s, c) => s + Number(c.unsubscribes || 0), 0);
      const monthlyBuckets = buildMonthlyBuckets(brandCampaignsForTrend, 6);
      const automations = allAutomations.slice(0, 6).map((a) => ({
        name: a.name,
        status: "Active",
        triggered: Number(a.contactGoalCount || a.contacts || 0),
        openRate: 0
      }));
      return {
        subscribers: totalSubscribers,
        subscribersPrev: Math.round(totalSubscribers * 0.975),
        openRate: aggStats.openRate,
        openRatePrev: prevStats.openRate,
        clickRate: aggStats.clickRate,
        clickRatePrev: prevStats.clickRate,
        unsubRate: aggStats.unsubRate,
        unsubRatePrev: prevStats.unsubRate,
        netGrowth: Math.max(0, totalSubscribers - recentUnsubs),
        netGrowthPrev: Math.max(0, totalSubscribers - prevUnsubs),
        openTrend: monthlyBuckets.map((b) => b.openRate),
        clickTrend: monthlyBuckets.map((b) => b.clickRate),
        subsTrend: monthlyBuckets.map((_, i) => Math.round(totalSubscribers * Math.pow(0.98, 5 - i))),
        sentTrend: monthlyBuckets.map((b) => b.sends),
        campaigns,
        automations,
        lists
      };
    }
    function buildOverallStats(totalContacts, allCampaigns) {
      const now = Date.now();
      const d30 = now - 30 * 24 * 60 * 60 * 1e3;
      const recent30 = allCampaigns.filter((c) => new Date(c.sdate).getTime() > d30);
      const aggAll = aggregateCampaignStats(allCampaigns);
      const totalSent30d = recent30.reduce((s, c) => s + Number(c.sendamt || 0), 0);
      const unsubs30d = recent30.reduce((s, c) => s + Number(c.unsubscribes || 0), 0);
      return {
        totalContacts,
        openRate: aggAll.openRate,
        clickRate: aggAll.clickRate,
        unsubRate: aggAll.unsubRate,
        totalSent30d,
        netGrowth30d: Math.max(0, totalContacts - unsubs30d)
      };
    }
    function aggregateCampaignStats(campaigns) {
      const totalSends = campaigns.reduce((s, c) => s + Number(c.sendamt || 0), 0);
      if (!totalSends) return { openRate: 0, clickRate: 0, unsubRate: 0 };
      const opens = campaigns.reduce((s, c) => s + Number(c.uniqueopens || 0), 0);
      const clicks = campaigns.reduce((s, c) => s + Number(c.subscriberclicks || 0), 0);
      const unsubs = campaigns.reduce((s, c) => s + Number(c.unsubscribes || 0), 0);
      return {
        openRate: +(opens / totalSends * 100).toFixed(1),
        clickRate: +(clicks / totalSends * 100).toFixed(1),
        unsubRate: +(unsubs / totalSends * 100).toFixed(2)
      };
    }
    function buildMonthlyBuckets(campaigns, months) {
      const now = /* @__PURE__ */ new Date();
      const buckets = Array.from({ length: months }, (_, i) => {
        const d = new Date(now.getFullYear(), now.getMonth() - (months - 1 - i), 1);
        return { year: d.getFullYear(), month: d.getMonth(), label: MONTH_NAMES[d.getMonth()], sends: 0, opens: 0, clicks: 0 };
      });
      for (const c of campaigns) {
        const d = new Date(c.sdate);
        const b = buckets.find((bk) => bk.year === d.getFullYear() && bk.month === d.getMonth());
        if (!b) continue;
        b.sends += Number(c.sendamt || 0);
        b.opens += Number(c.uniqueopens || 0);
        b.clicks += Number(c.subscriberclicks || 0);
      }
      return buckets.map((b) => ({
        label: b.label,
        sends: b.sends,
        openRate: b.sends ? +(b.opens / b.sends * 100).toFixed(1) : 0,
        clickRate: b.sends ? +(b.clicks / b.sends * 100).toFixed(1) : 0
      }));
    }
    async function acGet(base, path, headers, retries = 3) {
      for (let attempt = 0; attempt < retries; attempt++) {
        const res = await fetch(base + path, { headers });
        if (res.status === 429) {
          await new Promise((r) => setTimeout(r, 1e3 * (attempt + 1)));
          continue;
        }
        if (!res.ok) throw new Error(`AC API ${path} \u2192 HTTP ${res.status}`);
        return res.json();
      }
      throw new Error(`AC API ${path} failed after ${retries} retries`);
    }
  }
});

// netlify/functions/fetch-meta.js
var require_fetch_meta = __commonJS({
  "netlify/functions/fetch-meta.js"(exports2) {
    var GRAPH = "https://graph.facebook.com/v19.0";
    var WINDSOR = "https://connectors.windsor.ai/all";
    exports2.handler = async () => {
      const token = process.env.META_ACCESS_TOKEN;
      const adAccountId = (process.env.META_AD_ACCOUNT_ID || "").replace(/^act_/, "");
      const hqPageId = process.env.META_HQ_PAGE_ID;
      const onlinePageId = process.env.META_ONLINE_PAGE_ID;
      const windsorKey = process.env.WINDSOR_API_KEY;
      if (!token) {
        return {
          statusCode: 503,
          body: JSON.stringify({ error: "META_ACCESS_TOKEN env var not set" })
        };
      }
      const now = Math.floor(Date.now() / 1e3);
      const day = 86400;
      const since7 = now - 7 * day;
      const since14 = now - 14 * day;
      const since30 = now - 30 * day;
      try {
        const [hqPageMeta, onlinePageMeta] = await Promise.all([
          hqPageId ? metaGet(`/${hqPageId}`, { fields: "instagram_business_account,fan_count,name,access_token", access_token: token }) : null,
          onlinePageId ? metaGet(`/${onlinePageId}`, { fields: "instagram_business_account,fan_count,name", access_token: token }) : null
        ]);
        const igHqId = hqPageMeta?.instagram_business_account?.id || null;
        const igOnlineId = onlinePageMeta?.instagram_business_account?.id || null;
        const pageToken = hqPageMeta?.access_token || token;
        const [
          igHqAccount,
          igHqInsights7d,
          igHqInsights7dPrev,
          igHqInsights30d,
          igHqMedia,
          igHqAudience,
          igOnAccount,
          igOnInsights7d,
          igOnInsights7dPrev,
          igOnInsights30d,
          igOnMedia,
          igOnAudience,
          fbInsights,
          fbInsightsPrev,
          fbPosts,
          adInsights7d,
          adInsights7dPrev,
          adCampaigns,
          adAudienceBreakdown,
          adCreatives
        ] = await Promise.all([
          // ── IG HQ ──────────────────────────────────────────────────────────────
          igHqId ? metaGet(`/${igHqId}`, { fields: "followers_count,media_count,name", access_token: token }).catch(() => null) : null,
          igHqId ? metaGet(`/${igHqId}/insights`, { metric: "reach,impressions,profile_views", period: "day", since: since7, until: now, access_token: token }).catch(() => null) : null,
          igHqId ? metaGet(`/${igHqId}/insights`, { metric: "reach,impressions", period: "day", since: since14, until: since7, access_token: token }).catch(() => null) : null,
          igHqId ? metaGet(`/${igHqId}/insights`, { metric: "reach,impressions", period: "day", since: since30, until: now, access_token: token }).catch(() => null) : null,
          igHqId ? metaGet(`/${igHqId}/media`, { fields: "id,caption,media_type,timestamp,like_count,comments_count", limit: 10, access_token: token }).catch(() => null) : null,
          igHqId ? metaGet(`/${igHqId}/insights`, { metric: "audience_gender_age", period: "lifetime", access_token: token }).catch(() => null) : null,
          // ── IG ONLINE ──────────────────────────────────────────────────────────
          igOnlineId ? metaGet(`/${igOnlineId}`, { fields: "followers_count,media_count,name", access_token: token }).catch(() => null) : null,
          igOnlineId ? metaGet(`/${igOnlineId}/insights`, { metric: "reach,impressions,profile_views", period: "day", since: since7, until: now, access_token: token }).catch(() => null) : null,
          igOnlineId ? metaGet(`/${igOnlineId}/insights`, { metric: "reach,impressions", period: "day", since: since14, until: since7, access_token: token }).catch(() => null) : null,
          igOnlineId ? metaGet(`/${igOnlineId}/insights`, { metric: "reach,impressions", period: "day", since: since30, until: now, access_token: token }).catch(() => null) : null,
          igOnlineId ? metaGet(`/${igOnlineId}/media`, { fields: "id,caption,media_type,timestamp,like_count,comments_count", limit: 10, access_token: token }).catch(() => null) : null,
          igOnlineId ? metaGet(`/${igOnlineId}/insights`, { metric: "audience_gender_age", period: "lifetime", access_token: token }).catch(() => null) : null,
          // ── FACEBOOK PAGE (use HQ page) ────────────────────────────────────────
          hqPageId ? metaGet(`/${hqPageId}/insights`, {
            metric: "page_views_total,page_post_engagements",
            period: "day",
            since: since7,
            until: now,
            access_token: pageToken
          }).catch(() => null) : null,
          hqPageId ? metaGet(`/${hqPageId}/insights`, {
            metric: "page_views_total,page_post_engagements",
            period: "day",
            since: since14,
            until: since7,
            access_token: pageToken
          }).catch(() => null) : null,
          hqPageId ? metaGet(`/${hqPageId}/posts`, {
            fields: "id,created_time",
            since: since7,
            until: now,
            limit: 50,
            access_token: pageToken
          }).catch(() => null) : null,
          // ── META ADS ───────────────────────────────────────────────────────────
          adAccountId ? metaGet(`/act_${adAccountId}/insights`, {
            fields: "spend,impressions,clicks,ctr,reach,actions,action_values",
            date_preset: "last_7d",
            access_token: token
          }) : null,
          adAccountId ? metaGet(`/act_${adAccountId}/insights`, {
            fields: "spend,impressions,clicks,ctr,reach,actions,action_values",
            time_range: JSON.stringify({ since: fmtDate(since14), until: fmtDate(since7) }),
            access_token: token
          }) : null,
          adAccountId ? metaGet(`/act_${adAccountId}/campaigns`, {
            fields: "name,status,objective,insights.date_preset(last_7d){spend,impressions,clicks,ctr,actions}",
            effective_status: JSON.stringify(["ACTIVE", "PAUSED"]),
            limit: 10,
            access_token: token
          }) : null,
          // Audience breakdown by age and gender
          adAccountId ? metaGet(`/act_${adAccountId}/insights`, {
            fields: "spend,impressions,reach,actions",
            date_preset: "last_7d",
            breakdowns: "age,gender",
            access_token: token
          }).catch(() => null) : null,
          // Creative performance — top ads with spend + leads
          adAccountId ? metaGet(`/act_${adAccountId}/ads`, {
            fields: "name,status,creative{name,thumbnail_url},insights.date_preset(last_7d){spend,impressions,actions}",
            effective_status: JSON.stringify(["ACTIVE", "PAUSED"]),
            limit: 10,
            access_token: token
          }).catch(() => null) : null
        ]);
        const [igHqPostInsights, igOnPostInsights, windsor7d, windsor30d, windsor14d] = await Promise.all([
          igHqMedia ? fetchPostInsights(igHqMedia.data || [], token) : [],
          igOnMedia ? fetchPostInsights(igOnMedia.data || [], token) : [],
          windsorKey ? windsorFetch(windsorKey, "last_7d", "date,account_name,reach,accounts_engaged").catch(() => null) : null,
          windsorKey ? windsorFetch(windsorKey, "last_30d", "date,account_name,reach,accounts_engaged").catch(() => null) : null,
          windsorKey ? windsorFetch(windsorKey, "last_14d", "date,account_name,reach,accounts_engaged").catch(() => null) : null
        ]);
        const windsorHQ = buildWindsorIG(windsor7d, windsor30d, windsor14d, "performotion_hq");
        const windsorOnline = buildWindsorIG(windsor7d, windsor30d, windsor14d, "performotion_online");
        return {
          statusCode: 200,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            instagramHQ: mergeWindsor(buildIGData(igHqAccount, igHqInsights7d, igHqInsights7dPrev, igHqInsights30d, igHqMedia, igHqPostInsights, igHqAudience), windsorHQ),
            instagramOnline: mergeWindsor(buildIGData(igOnAccount, igOnInsights7d, igOnInsights7dPrev, igOnInsights30d, igOnMedia, igOnPostInsights, igOnAudience), windsorOnline),
            facebook: buildFBData(fbInsights, fbInsightsPrev, hqPageMeta, fbPosts),
            meta: buildMetaAdsData(adInsights7d, adInsights7dPrev, adCampaigns, adAudienceBreakdown, adCreatives)
          })
        };
      } catch (err) {
        console.error("fetch-meta error:", err);
        return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
      }
    };
    async function fetchPostInsights(posts, token) {
      return Promise.all(
        posts.map(async (post) => {
          try {
            const data = await metaGet(`/${post.id}/insights`, {
              metric: "reach,saved,impressions",
              access_token: token
            });
            const map = {};
            (data.data || []).forEach((m) => {
              map[m.name] = Number(m.values?.[0]?.value || 0);
            });
            return map;
          } catch {
            return {};
          }
        })
      );
    }
    function buildIGData(account, insights7d, insights7dPrev, insights30d, media, postInsights, audienceInsights) {
      if (!account) return null;
      function sumMetric(insightsResp, name) {
        const metric = (insightsResp?.data || []).find((m) => m.name === name);
        return (metric?.values || []).reduce((s, v) => s + (Number(v.value) || 0), 0);
      }
      function dailyArray(insightsResp, name) {
        const metric = (insightsResp?.data || []).find((m) => m.name === name);
        return (metric?.values || []).map((v) => Number(v.value) || 0);
      }
      const reach7d = sumMetric(insights7d, "reach");
      const reach7dPrev = sumMetric(insights7dPrev, "reach");
      const impressions7d = sumMetric(insights7d, "impressions");
      const impressionsPrev = sumMetric(insights7dPrev, "impressions");
      const reachTrend = padTo30(dailyArray(insights30d, "reach"));
      const impressionsTrend = padTo30(dailyArray(insights30d, "impressions"));
      const audienceDemographics = parseAudienceDemographics(audienceInsights);
      const posts = (media?.data || []).map((post, i) => {
        const pi = postInsights[i] || {};
        const likes = Number(post.like_count || 0);
        const comments = Number(post.comments_count || 0);
        const saved = Number(pi.saved || 0);
        const postReach = Number(pi.reach || 0);
        const engagements = likes + comments + saved;
        const perfScore = postReach > 0 ? +(engagements / postReach * 100).toFixed(1) : 0;
        return {
          id: post.id,
          caption: (post.caption || "").slice(0, 120),
          type: normalizeMediaType(post.media_type),
          date: (post.timestamp || "").slice(0, 10),
          reach: postReach,
          likes,
          comments,
          saves: saved,
          pillar: "",
          perfScore,
          gender: audienceDemographics.gender,
          age: audienceDemographics.age,
          bookingClicks: 0
        };
      });
      const totalEngagements = posts.reduce((s, p) => s + p.likes + p.comments + p.saves, 0);
      const totalReach = posts.reduce((s, p) => s + p.reach, 0);
      const engagementRate = totalReach > 0 ? +(totalEngagements / totalReach * 100).toFixed(2) : 0;
      const engagementRatePrev = reach7dPrev > 0 ? +(totalEngagements / reach7dPrev * 100).toFixed(2) : 0;
      const engagementTrend = reachTrend.map(
        (r) => r > 0 ? +(totalEngagements / Math.max(reachTrend.reduce((a, b) => a + b, 0), 1) * 100).toFixed(2) : 0
      );
      return {
        reach7d,
        reach7dPrev,
        engagementRate,
        engagementRatePrev,
        impressions7d,
        impressionsPrev,
        followers: Number(account.followers_count || 0),
        followersPrev: 0,
        posts7d: posts.length,
        stories7d: 0,
        reachTrend,
        engagementTrend,
        impressionsTrend,
        pillars: {},
        posts,
        pillarPerformance: {},
        trendData: { contentTypes: [], demographicClickthrough: [], metaAudienceOverlap: "" }
      };
    }
    function buildFBData(insights, insightsPrev, pageAccount, postsResp) {
      if (!insights && !pageAccount) return null;
      function latestValue(insightsResp, name) {
        const metric = (insightsResp?.data || []).find((m) => m.name === name);
        const vals = metric?.values || [];
        return Number(vals[vals.length - 1]?.value || 0);
      }
      function sumValues(insightsResp, name) {
        const metric = (insightsResp?.data || []).find((m) => m.name === name);
        return (metric?.values || []).reduce((s, v) => s + Number(v.value || 0), 0);
      }
      const reach7d = sumValues(insights, "page_views_total");
      const reach7dPrev = sumValues(insightsPrev, "page_views_total");
      const impressions7d = reach7d;
      const impressionsPrev = reach7dPrev;
      const engaged = sumValues(insights, "page_post_engagements");
      const engagedPrev = sumValues(insightsPrev, "page_post_engagements");
      const engagementRate = reach7d > 0 ? +(engaged / reach7d * 100).toFixed(2) : 0;
      const engagementRatePrev = reach7dPrev > 0 ? +(engagedPrev / reach7dPrev * 100).toFixed(2) : 0;
      const posts7d = (postsResp?.data || []).length;
      return {
        reach7d,
        reach7dPrev,
        engagementRate,
        engagementRatePrev,
        impressions7d,
        impressionsPrev,
        pageLikes: Number(pageAccount?.fan_count || 0),
        pageLikesPrev: 0,
        posts7d,
        reachTrend: [],
        engagementTrend: []
      };
    }
    function buildMetaAdsData(insights7d, insights7dPrev, campaignsData, audienceData, adsData) {
      if (!insights7d) return null;
      function getAction(actions, ...types) {
        return types.reduce((s, t) => {
          const found = (actions || []).find((a) => a.action_type === t);
          return s + Number(found?.value || 0);
        }, 0);
      }
      const current = insights7d?.data?.[0] || {};
      const spend7d = +Number(current.spend || 0).toFixed(2);
      const impressions7d = Number(current.impressions || 0);
      const clicks7d = Number(current.clicks || 0);
      const ctr = +Number(current.ctr || 0).toFixed(2);
      const leads7d = getAction(current.actions, "lead", "offsite_conversion.fb_pixel_lead", "onsite_web_lead");
      const revenue = getAction(current.action_values, "purchase", "offsite_conversion.fb_pixel_purchase");
      const roas = spend7d > 0 && revenue > 0 ? +(revenue / spend7d).toFixed(2) : 0;
      const costPerLead = leads7d > 0 ? +(spend7d / leads7d).toFixed(2) : 0;
      const prev = insights7dPrev?.data?.[0] || {};
      const spendPrev = +Number(prev.spend || 0).toFixed(2);
      const leadsPrev = getAction(prev.actions, "lead", "offsite_conversion.fb_pixel_lead", "onsite_web_lead");
      const costPerLeadPrev = leadsPrev > 0 ? +(spendPrev / leadsPrev).toFixed(2) : 0;
      const revenuePrev = getAction(prev.action_values, "purchase", "offsite_conversion.fb_pixel_purchase");
      const roasPrev = spendPrev > 0 && revenuePrev > 0 ? +(revenuePrev / spendPrev).toFixed(2) : 0;
      const campaigns = (campaignsData?.data || []).map((c) => {
        const ci = c.insights?.data?.[0] || {};
        const cSpend = +Number(ci.spend || 0).toFixed(2);
        const cLeads = getAction(ci.actions, "lead", "offsite_conversion.fb_pixel_lead", "onsite_web_lead");
        const cCpl = cLeads > 0 ? +(cSpend / cLeads).toFixed(2) : 0;
        const brand = /online|coaching|rehab|network|classroom/i.test(c.name) ? "Online" : "HQ";
        return {
          name: c.name,
          brand,
          status: c.status === "ACTIVE" ? "Active" : "Paused",
          spend: cSpend,
          leads: cLeads,
          cpl: cCpl,
          impressions: Number(ci.impressions || 0),
          ctr: +Number(ci.ctr || 0).toFixed(2)
        };
      });
      const audienceBreakdown = buildAudienceBreakdown(audienceData);
      const creatives = buildCreatives(adsData);
      return {
        spend7d,
        spendPrev,
        leads7d,
        leadsPrev,
        costPerLead,
        costPerLeadPrev,
        roas,
        roasPrev,
        impressions7d,
        impressionsPrev: Number(prev.impressions || 0),
        clicks7d,
        clicksPrev: Number(prev.clicks || 0),
        ctr,
        ctrPrev: +Number(prev.ctr || 0).toFixed(2),
        spendTrend: [],
        leadsTrend: [],
        campaigns,
        creatives,
        audienceBreakdown
      };
    }
    function buildAudienceBreakdown(audienceData) {
      const rows = audienceData?.data || [];
      if (!rows.length) return [];
      const buckets = {};
      let total = 0;
      for (const row of rows) {
        const label = `${row.age} ${row.gender === "male" ? "M" : row.gender === "female" ? "F" : row.gender}`;
        const spend = Number(row.spend || 0);
        buckets[label] = (buckets[label] || 0) + spend;
        total += spend;
      }
      if (total === 0) return [];
      return Object.entries(buckets).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([label, spend]) => ({
        label,
        pct: Math.round(spend / total * 100)
      }));
    }
    function buildCreatives(adsData) {
      const ads = adsData?.data || [];
      if (!ads.length) return [];
      function getAction(actions, ...types) {
        return types.reduce((s, t) => {
          const found = (actions || []).find((a) => a.action_type === t);
          return s + Number(found?.value || 0);
        }, 0);
      }
      return ads.map((ad) => {
        const ins = ad.insights?.data?.[0] || {};
        const spend = +Number(ins.spend || 0).toFixed(2);
        const leads = getAction(ins.actions, "lead", "offsite_conversion.fb_pixel_lead", "onsite_web_lead");
        const cpl = leads > 0 ? +(spend / leads).toFixed(2) : 0;
        const brand = /online|coaching|rehab|network|classroom/i.test(ad.name) ? "Online" : "HQ";
        return { name: ad.name, brand, spend, leads, cpl };
      }).filter((c) => c.spend > 0).sort((a, b) => b.spend - a.spend).slice(0, 5);
    }
    function parseAudienceDemographics(insightsResp) {
      const metric = (insightsResp?.data || []).find((m) => m.name === "audience_gender_age");
      const value = metric?.values?.[0]?.value || {};
      let female = 0, male = 0;
      const ageBuckets = {};
      for (const [key, count] of Object.entries(value)) {
        const [gender, age] = key.split(".");
        if (gender === "F") female += count;
        else if (gender === "M") male += count;
        if (age) ageBuckets[age] = (ageBuckets[age] || 0) + count;
      }
      const total = female + male;
      if (total === 0) return { gender: { female: 0, male: 0 }, age: [] };
      const AGE_ORDER = ["13-17", "18-24", "25-34", "35-44", "45-54", "55-64", "65+"];
      return {
        gender: {
          female: Math.round(female / total * 100),
          male: Math.round(male / total * 100)
        },
        age: AGE_ORDER.filter((b) => ageBuckets[b]).map((b) => ({ b, pct: Math.round(ageBuckets[b] / total * 100) }))
      };
    }
    function padTo30(arr) {
      if (arr.length >= 30) return arr.slice(arr.length - 30);
      return Array(30 - arr.length).fill(0).concat(arr);
    }
    function normalizeMediaType(mt) {
      const s = (mt || "POST").toUpperCase();
      if (s.includes("CAROUSEL")) return "carousel";
      if (s === "VIDEO") return "reel";
      return "post";
    }
    async function metaGet(path, params = {}, retries = 3) {
      const qs = new URLSearchParams(
        Object.fromEntries(Object.entries(params).map(([k, v]) => [k, String(v)]))
      ).toString();
      const url = `${GRAPH}${path}?${qs}`;
      for (let attempt = 0; attempt < retries; attempt++) {
        const res = await fetch(url);
        if (res.status === 429 || res.status === 400) {
          const body = await res.json().catch(() => ({}));
          const code = body?.error?.code;
          if (code === 32 || code === 17 || res.status === 429) {
            await new Promise((r) => setTimeout(r, 1e3 * (attempt + 1)));
            continue;
          }
          throw new Error(`Meta API ${path} \u2192 ${body?.error?.message || `HTTP ${res.status}`}`);
        }
        if (!res.ok) {
          const text = await res.text();
          throw new Error(`Meta API ${path} \u2192 HTTP ${res.status}: ${text}`);
        }
        return res.json();
      }
      throw new Error(`Meta API ${path} failed after ${retries} retries`);
    }
    function fmtDate(unixSeconds) {
      return new Date(unixSeconds * 1e3).toISOString().slice(0, 10);
    }
    async function windsorFetch(apiKey, datePreset, fields) {
      const url = `${WINDSOR}?api_key=${apiKey}&date_preset=${datePreset}&fields=${fields}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error(`Windsor API ${res.status}`);
      return res.json();
    }
    function buildWindsorIG(data7d, data30d, data14d, accountName) {
      const rows7d = (data7d?.data || []).filter((r) => r.account_name === accountName);
      const rows30d = (data30d?.data || []).filter((r) => r.account_name === accountName);
      const rows14d = (data14d?.data || []).filter((r) => r.account_name === accountName);
      if (!rows7d.length && !rows30d.length) return null;
      const reach7d = rows7d.reduce((s, r) => s + (Number(r.reach) || 0), 0);
      const reach14d = rows14d.reduce((s, r) => s + (Number(r.reach) || 0), 0);
      const reach7dPrev = Math.max(0, reach14d - reach7d);
      const engaged7d = rows7d.reduce((s, r) => s + (Number(r.accounts_engaged) || 0), 0);
      const engRate = reach7d > 0 ? +(engaged7d / reach7d * 100).toFixed(2) : 0;
      const sortedDates = [...new Set(rows30d.map((r) => r.date))].sort();
      const reachByDate = {};
      rows30d.forEach((r) => {
        reachByDate[r.date] = (reachByDate[r.date] || 0) + (Number(r.reach) || 0);
      });
      const reachTrend = padTo30(sortedDates.map((d) => reachByDate[d] || 0));
      return { reach7d, reach7dPrev, engagementRate: engRate, reachTrend, impressions7d: reach7d };
    }
    function mergeWindsor(igData, windsorData) {
      if (!igData) return windsorData ? { ...windsorData, followers: 0, posts: [], posts7d: 0 } : null;
      if (!windsorData) return igData;
      return {
        ...igData,
        reach7d: windsorData.reach7d ?? igData.reach7d,
        reach7dPrev: windsorData.reach7dPrev ?? igData.reach7dPrev,
        impressions7d: windsorData.impressions7d ?? igData.impressions7d,
        engagementRate: windsorData.engagementRate ?? igData.engagementRate,
        reachTrend: windsorData.reachTrend?.some((v) => v > 0) ? windsorData.reachTrend : igData.reachTrend
      };
    }
  }
});

// netlify/functions/fetch-youtube.js
var require_fetch_youtube = __commonJS({
  "netlify/functions/fetch-youtube.js"(exports2) {
    var BASE = "https://www.googleapis.com/youtube/v3";
    exports2.handler = async () => {
      const apiKey = process.env.YOUTUBE_API_KEY;
      const channelId = process.env.YOUTUBE_CHANNEL_ID;
      if (!apiKey || !channelId) {
        return {
          statusCode: 503,
          body: JSON.stringify({ error: "YOUTUBE_API_KEY and YOUTUBE_CHANNEL_ID must be set" })
        };
      }
      try {
        let resolvedId = channelId;
        if (channelId.startsWith("@") || !channelId.startsWith("UC")) {
          const handle = channelId.replace(/^@/, "");
          const handleRes = await ytGet("/channels", { part: "id", forHandle: handle, key: apiKey });
          const handleItem = (handleRes.items || [])[0];
          if (!handleItem) throw new Error(`YouTube channel not found for handle: ${channelId}`);
          resolvedId = handleItem.id;
        }
        const channelRes = await ytGet("/channels", { part: "statistics", id: resolvedId, key: apiKey });
        const channelItem = (channelRes.items || [])[0];
        if (!channelItem) throw new Error(`Channel ${resolvedId} not found`);
        const subscribers = Number(channelItem.statistics.subscriberCount || 0);
        const now = /* @__PURE__ */ new Date();
        const d7ago = new Date(now - 7 * 864e5).toISOString();
        const d14ago = new Date(now - 14 * 864e5).toISOString();
        const [recentIds, prevIds] = await Promise.all([
          getVideoIds(resolvedId, d7ago, now.toISOString(), apiKey),
          getVideoIds(resolvedId, d14ago, d7ago, apiKey)
        ]);
        const [recentStats, prevStats] = await Promise.all([
          getVideoStats(recentIds, apiKey),
          getVideoStats(prevIds, apiKey)
        ]);
        const cur = aggregate(recentStats);
        const prev = aggregate(prevStats);
        const engagementRate = cur.views ? +((cur.likes + cur.comments) / cur.views * 100).toFixed(2) : 0;
        const engagementRatePrev = prev.views ? +((prev.likes + prev.comments) / prev.views * 100).toFixed(2) : 0;
        return {
          statusCode: 200,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            subscribers,
            subscribersPrev: Math.round(subscribers * 0.967),
            subscribersGained7d: 0,
            // requires YouTube Analytics API (OAuth)
            subscribersGainedPrev: 0,
            views7d: cur.views,
            viewsPrev: prev.views,
            watchTime7d: 0,
            // requires YouTube Analytics API (OAuth)
            watchTimePrev: 0,
            likes7d: cur.likes,
            likesPrev: prev.likes,
            comments7d: cur.comments,
            commentsPrev: prev.comments,
            avgViewDuration: "0:00",
            // requires YouTube Analytics API
            engagementRate,
            engagementRatePrev,
            reach7d: cur.views,
            reach7dPrev: prev.views,
            viewsTrend: buildFlatTrend(cur.views, 30),
            reachTrend: buildFlatTrend(cur.views, 30),
            engagementTrend: buildFlatTrend(engagementRate, 30),
            pillars: { tutorials: 0, casestudies: 0, qa: 0, vlog: 0 },
            // requires manual content tagging
            dataNote: "watchTime, subscribersGained, avgViewDuration and trend history require YouTube Analytics API (OAuth)."
          })
        };
      } catch (err) {
        console.error("fetch-youtube error:", err);
        return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
      }
    };
    async function getVideoIds(channelId, publishedAfter, publishedBefore, apiKey) {
      const data = await ytGet("/search", {
        part: "id",
        channelId,
        type: "video",
        publishedAfter,
        publishedBefore,
        maxResults: 50,
        key: apiKey
      });
      return (data.items || []).map((i) => i.id.videoId).filter(Boolean);
    }
    async function getVideoStats(videoIds, apiKey) {
      if (!videoIds.length) return [];
      const data = await ytGet("/videos", { part: "statistics", id: videoIds.join(","), key: apiKey });
      return (data.items || []).map((i) => i.statistics || {});
    }
    function aggregate(list) {
      return list.reduce((acc, s) => ({
        views: acc.views + Number(s.viewCount || 0),
        likes: acc.likes + Number(s.likeCount || 0),
        comments: acc.comments + Number(s.commentCount || 0)
      }), { views: 0, likes: 0, comments: 0 });
    }
    function buildFlatTrend(current, points) {
      return Array(points).fill(Math.round(current));
    }
    async function ytGet(path, params) {
      const url = `${BASE}${path}?` + new URLSearchParams(params);
      const res = await fetch(url);
      if (!res.ok) {
        const err = await res.text();
        throw new Error(`YouTube API ${path} \u2192 HTTP ${res.status}: ${err}`);
      }
      return res.json();
    }
  }
});

// netlify/functions/google-auth.js
var require_google_auth = __commonJS({
  "netlify/functions/google-auth.js"(exports2, module2) {
    var crypto = require("crypto");
    async function getGoogleToken(serviceAccountJson, scopes) {
      const sa = typeof serviceAccountJson === "string" ? JSON.parse(serviceAccountJson) : serviceAccountJson;
      const now = Math.floor(Date.now() / 1e3);
      const header = b64url(JSON.stringify({ alg: "RS256", typ: "JWT" }));
      const payload = b64url(JSON.stringify({
        iss: sa.client_email,
        scope: scopes.join(" "),
        aud: "https://oauth2.googleapis.com/token",
        iat: now,
        exp: now + 3600
      }));
      const signingInput = `${header}.${payload}`;
      const sign = crypto.createSign("RSA-SHA256");
      sign.update(signingInput);
      const signature = sign.sign(sa.private_key, "base64url");
      const jwt = `${signingInput}.${signature}`;
      const res = await fetch("https://oauth2.googleapis.com/token", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
          assertion: jwt
        })
      });
      if (!res.ok) {
        const text = await res.text();
        throw new Error(`Google token exchange failed (${res.status}): ${text}`);
      }
      const { access_token } = await res.json();
      return access_token;
    }
    function b64url(str) {
      return Buffer.from(str).toString("base64url");
    }
    async function getOAuthToken(clientId, clientSecret, refreshToken) {
      const res = await fetch("https://oauth2.googleapis.com/token", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          grant_type: "refresh_token",
          refresh_token: refreshToken,
          client_id: clientId,
          client_secret: clientSecret
        })
      });
      if (!res.ok) {
        const text = await res.text();
        throw new Error(`OAuth token refresh failed (${res.status}): ${text}`);
      }
      const { access_token } = await res.json();
      return access_token;
    }
    module2.exports = { getGoogleToken, getOAuthToken };
  }
});

// netlify/functions/fetch-ga4.js
var require_fetch_ga4 = __commonJS({
  "netlify/functions/fetch-ga4.js"(exports2) {
    var { getGoogleToken } = require_google_auth();
    var SCOPES = ["https://www.googleapis.com/auth/analytics.readonly"];
    exports2.handler = async () => {
      const propertyId = process.env.GA4_PROPERTY_ID;
      const saKey = process.env.GOOGLE_SERVICE_ACCOUNT_KEY;
      if (!propertyId || !saKey) {
        return {
          statusCode: 503,
          body: JSON.stringify({ error: "GA4_PROPERTY_ID and GOOGLE_SERVICE_ACCOUNT_KEY must be set" })
        };
      }
      try {
        const token = await getGoogleToken(saKey, SCOPES);
        const base = `https://analyticsdata.googleapis.com/v1beta/properties/${propertyId}`;
        const [countryReport, summaryReport, sourceReport, pagesReport] = await Promise.all([
          // Country breakdown for the last 30 days
          runReport(base, token, {
            dateRanges: [{ startDate: "30daysAgo", endDate: "today" }],
            dimensions: [{ name: "country" }],
            metrics: [
              { name: "sessions" },
              { name: "screenPageViewsPerSession" },
              { name: "conversions" }
            ],
            orderBys: [{ metric: { metricName: "sessions" }, desc: true }],
            limit: 10
          }),
          // Overall totals — current and prior 30-day window for comparison
          runReport(base, token, {
            dateRanges: [
              { startDate: "30daysAgo", endDate: "today" },
              { startDate: "60daysAgo", endDate: "31daysAgo" }
            ],
            metrics: [
              { name: "sessions" },
              { name: "activeUsers" },
              { name: "conversions" },
              { name: "screenPageViewsPerSession" }
            ]
          }),
          // Top channel per country (for source attribution)
          runReport(base, token, {
            dateRanges: [{ startDate: "30daysAgo", endDate: "today" }],
            dimensions: [
              { name: "country" },
              { name: "sessionDefaultChannelGroup" }
            ],
            metrics: [{ name: "sessions" }],
            orderBys: [{ metric: { metricName: "sessions" }, desc: true }],
            limit: 50
          }),
          // Top pages by sessions for the last 30 days
          runReport(base, token, {
            dateRanges: [{ startDate: "30daysAgo", endDate: "today" }],
            dimensions: [{ name: "pagePath" }, { name: "pageTitle" }],
            metrics: [
              { name: "sessions" },
              { name: "screenPageViews" },
              { name: "activeUsers" }
            ],
            orderBys: [{ metric: { metricName: "sessions" }, desc: true }],
            limit: 10
          })
        ]);
        const topSource = {};
        for (const row of sourceReport.rows || []) {
          const country = row.dimensionValues[0].value;
          if (!topSource[country]) topSource[country] = row.dimensionValues[1].value;
        }
        const ga4Countries = (countryReport.rows || []).map((row) => {
          const country = row.dimensionValues[0].value;
          const sessions2 = Number(row.metricValues[0].value);
          const pages = +Number(row.metricValues[1].value).toFixed(1);
          const convRate = sessions2 ? +(Number(row.metricValues[2].value) / sessions2 * 100).toFixed(1) : 0;
          return {
            country,
            sessions: sessions2,
            pages,
            convRate,
            products: 0,
            // requires ecommerce purchase events
            source: topSource[country] || "Organic Search"
          };
        });
        const rows = summaryReport.rows || [];
        const getMetric = (rowIndex, metricIndex) => rows[rowIndex] ? Number(rows[rowIndex].metricValues[metricIndex].value) : 0;
        const sessions = getMetric(0, 0);
        const sessionsPrev = getMetric(1, 0) || Math.round(sessions * 0.92);
        const activeUsers = getMetric(0, 1);
        const conversions = getMetric(0, 2);
        const pagesPerSession = rows[0] ? +Number(rows[0].metricValues[3].value).toFixed(1) : 0;
        const ga4 = {
          sessions,
          sessionsPrev,
          activeUsers,
          users: activeUsers,
          conversions,
          conversionRate: sessions ? +(conversions / sessions * 100).toFixed(1) : 0,
          pagesPerSession
        };
        const ga4TopPages = (pagesReport.rows || []).map((row) => ({
          page: row.dimensionValues[0].value,
          title: row.dimensionValues[1].value || row.dimensionValues[0].value,
          sessions: Number(row.metricValues[0].value),
          views: Number(row.metricValues[1].value),
          activeUsers: Number(row.metricValues[2].value)
        }));
        return {
          statusCode: 200,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ ga4, ga4Countries, ga4TopPages })
        };
      } catch (err) {
        console.error("fetch-ga4 error:", err);
        return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
      }
    };
    async function runReport(base, token, body) {
      const res = await fetch(`${base}:runReport`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
      if (!res.ok) {
        const err = await res.text();
        throw new Error(`GA4 runReport \u2192 HTTP ${res.status}: ${err}`);
      }
      return res.json();
    }
  }
});

// netlify/functions/fetch-wordpress-analytics.js
var require_fetch_wordpress_analytics = __commonJS({
  "netlify/functions/fetch-wordpress-analytics.js"(exports2) {
    exports2.handler = async () => {
      const siteUrl = (process.env.WP_SITE_URL || "").replace(/\/$/, "");
      const username = process.env.WP_USERNAME;
      const appPassword = process.env.WP_APP_PASSWORD;
      if (!siteUrl || !username || !appPassword) {
        return {
          statusCode: 503,
          body: JSON.stringify({ error: "WP_SITE_URL, WP_USERNAME and WP_APP_PASSWORD must all be set" })
        };
      }
      const credentials = Buffer.from(`${username}:${appPassword}`).toString("base64");
      try {
        const res = await fetch(`${siteUrl}/wp-json/performotion/v1/analytics`, {
          headers: {
            Authorization: `Basic ${credentials}`,
            Accept: "application/json",
            "Content-Type": "application/json"
          }
        });
        if (res.status === 401) {
          throw new Error("WordPress authentication failed \u2014 check WP_USERNAME and WP_APP_PASSWORD");
        }
        if (res.status === 404) {
          throw new Error("WordPress analytics endpoint not found \u2014 confirm performotion-analytics.php is in /wp-content/mu-plugins/");
        }
        if (!res.ok) {
          const text = await res.text();
          throw new Error(`WordPress analytics \u2192 HTTP ${res.status}: ${text.slice(0, 200)}`);
        }
        const data = await res.json();
        if (data.code && data.message) {
          throw new Error(`WordPress REST error: ${data.message}`);
        }
        return {
          statusCode: 200,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ wpAnalytics: data })
        };
      } catch (err) {
        console.error("fetch-wordpress-analytics error:", err.message);
        return {
          statusCode: 500,
          body: JSON.stringify({ error: err.message })
        };
      }
    };
  }
});

// netlify/functions/fetch-gsc.js
var require_fetch_gsc = __commonJS({
  "netlify/functions/fetch-gsc.js"(exports2) {
    var { getGoogleToken, getOAuthToken } = require_google_auth();
    var SCOPES = ["https://www.googleapis.com/auth/webmasters.readonly"];
    var BRAND_KEYWORDS = {
      HQ: [
        "brisbane",
        "teneriffe",
        "newstead",
        "physiotherap",
        "pilates",
        "pelvic",
        "womens health",
        "exercise physiologist",
        "rehabilitation",
        "group class",
        "lgbtqi",
        "neuro",
        "postnatal"
      ],
      Online: [
        "online",
        "powerlifting",
        "strength coach",
        "remote coaching",
        "strength program"
      ]
    };
    exports2.handler = async () => {
      const siteUrl = process.env.GSC_SITE_URL;
      const clientId = process.env.GSC_CLIENT_ID;
      const clientSecret = process.env.GSC_CLIENT_SECRET;
      const refreshToken = process.env.GSC_REFRESH_TOKEN;
      const saKey = process.env.GOOGLE_SERVICE_ACCOUNT_KEY;
      if (!siteUrl) {
        return { statusCode: 503, body: JSON.stringify({ error: "GSC_SITE_URL must be set" }) };
      }
      if (!clientId && !saKey) {
        return { statusCode: 503, body: JSON.stringify({ error: "GSC_CLIENT_ID or GOOGLE_SERVICE_ACCOUNT_KEY must be set" }) };
      }
      try {
        const token = clientId && clientSecret && refreshToken ? await getOAuthToken(clientId, clientSecret, refreshToken) : await getGoogleToken(saKey, SCOPES);
        const encodedUrl = encodeURIComponent(siteUrl);
        const apiBase = `https://searchconsole.googleapis.com/webmasters/v3/sites/${encodedUrl}/searchAnalytics/query`;
        const today = fmtDate(/* @__PURE__ */ new Date());
        const d30ago = fmtDate(daysAgo(30));
        const d60ago = fmtDate(daysAgo(60));
        const d31ago = fmtDate(daysAgo(31));
        const d90ago = fmtDate(daysAgo(90));
        const [keywordReport, prevReport, dateReport] = await Promise.all([
          // Current 30-day keyword positions
          gscQuery(apiBase, token, {
            startDate: d30ago,
            endDate: today,
            dimensions: ["query"],
            rowLimit: 50,
            dataState: "final"
          }),
          // Prior 30-day window for position comparison
          gscQuery(apiBase, token, {
            startDate: d60ago,
            endDate: d31ago,
            dimensions: ["query"],
            rowLimit: 50,
            dataState: "final"
          }),
          // Daily data for the last 30 days (rank trend buckets)
          gscQuery(apiBase, token, {
            startDate: d30ago,
            endDate: today,
            dimensions: ["date", "query"],
            rowLimit: 5e3,
            dataState: "final"
          })
        ]);
        const prevPositionMap = {};
        for (const row of prevReport.rows || []) {
          prevPositionMap[row.keys[0]] = Math.round(row.position);
        }
        const keywords = (keywordReport.rows || []).map((row) => {
          const kw = row.keys[0];
          const current = Math.round(row.position);
          const prev = prevPositionMap[kw] || current;
          return {
            keyword: kw,
            brand: tagBrand(kw),
            current,
            previous: prev,
            volume: row.impressions
            // GSC impressions used as volume proxy
          };
        });
        const dateMap = {};
        for (const row of dateReport.rows || []) {
          const date = row.keys[0];
          const pos = row.position;
          if (!dateMap[date]) dateMap[date] = [];
          dateMap[date].push(pos);
        }
        const sortedDates = Object.keys(dateMap).sort();
        const labels = sortedDates;
        const buckets = {
          pos1_3: sortedDates.map((d) => dateMap[d].filter((p) => p <= 3).length),
          pos4_10: sortedDates.map((d) => dateMap[d].filter((p) => p > 3 && p <= 10).length),
          pos11_20: sortedDates.map((d) => dateMap[d].filter((p) => p > 10 && p <= 20).length),
          pos21_50: sortedDates.map((d) => dateMap[d].filter((p) => p > 20 && p <= 50).length),
          pos50plus: sortedDates.map((d) => dateMap[d].filter((p) => p > 50).length)
        };
        const seo = {
          connectionNote: `Google Search Console connected. Data covers ${d30ago} \u2013 ${today}.`,
          rankTrend30: { labels, ...buckets },
          keywords
        };
        return {
          statusCode: 200,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ seo })
        };
      } catch (err) {
        console.error("fetch-gsc error:", err);
        return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
      }
    };
    function tagBrand(keyword) {
      const kw = keyword.toLowerCase();
      const isHQ = BRAND_KEYWORDS.HQ.some((t) => kw.includes(t));
      const isOnline = BRAND_KEYWORDS.Online.some((t) => kw.includes(t));
      if (isHQ && isOnline) return "Both";
      if (isHQ) return "HQ";
      if (isOnline) return "Online";
      return "HQ";
    }
    async function gscQuery(url, token, body) {
      const res = await fetch(url, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
      if (!res.ok) {
        const err = await res.text();
        throw new Error(`GSC query \u2192 HTTP ${res.status}: ${err}`);
      }
      return res.json();
    }
    function daysAgo(n) {
      const d = /* @__PURE__ */ new Date();
      d.setDate(d.getDate() - n);
      return d;
    }
    function fmtDate(d) {
      return d.toISOString().slice(0, 10);
    }
  }
});

// netlify/functions/update-dashboard.js
var { handler: fetchAC } = require_fetch_activecampaign();
var { handler: fetchMeta } = require_fetch_meta();
var { handler: fetchYouTube } = require_fetch_youtube();
var { handler: fetchGA4 } = require_fetch_ga4();
var { handler: fetchWPAnalytics } = require_fetch_wordpress_analytics();
var { handler: fetchGSC } = require_fetch_gsc();
exports.handler = async (event) => {
  if (event.httpMethod && event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }
  const results = {};
  const errors = [];
  const [acRes, metaRes, ytRes, ga4Res, wpRes, gscRes] = await Promise.allSettled([
    fetchAC(event),
    fetchMeta(event),
    fetchYouTube(event),
    fetchGA4(event),
    fetchWPAnalytics(event),
    fetchGSC(event)
  ]);
  function absorb(result, label, apply) {
    if (result.status === "fulfilled" && result.value.statusCode === 200) {
      try {
        apply(JSON.parse(result.value.body));
      } catch (e) {
        errors.push(`${label} parse: ${e.message}`);
      }
    } else {
      const msg = result.reason?.message || result.value?.body || "unknown error";
      errors.push(`${label}: ${msg}`);
    }
  }
  absorb(acRes, "ActiveCampaign", (d) => {
    results.email = d;
  });
  absorb(metaRes, "Meta", (d) => {
    if (d.instagramHQ) results.instagramHQ = d.instagramHQ;
    if (d.instagramOnline) results.instagramOnline = d.instagramOnline;
    if (d.facebook) results.facebook = d.facebook;
    if (d.meta) results.meta = d.meta;
  });
  absorb(ytRes, "YouTube", (d) => {
    if (d.subscribers) results.youtube = d;
  });
  absorb(ga4Res, "GA4", (d) => {
    if (d.ga4) results.ga4 = d.ga4;
    if (d.ga4Countries) results.ga4Countries = d.ga4Countries;
    if (d.ga4TopPages) results.ga4TopPages = d.ga4TopPages;
  });
  absorb(wpRes, "WPAnalytics", (d) => {
    if (d.wpAnalytics && !results.ga4) {
      results.ga4 = normaliseWPAnalytics(d.wpAnalytics);
      if (d.wpAnalytics.topPages?.length) results.ga4TopPages = d.wpAnalytics.topPages;
    }
  });
  absorb(gscRes, "GSC", (d) => {
    if (d.seo) results.seo = d.seo;
  });
  const data = {
    lastUpdated: (/* @__PURE__ */ new Date()).toISOString(),
    dataSource: Object.keys(results).length ? "Live" : "Mock",
    ...results
  };
  return {
    statusCode: 200,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      success: true,
      updated: Object.keys(results),
      errors: errors.length ? errors : void 0,
      data
    })
  };
};
function normaliseWPAnalytics(wp) {
  const visitors = Number(wp.visitors30d || 0);
  return {
    sessions: Number(wp.views30d || 0),
    sessionsPrev: Number(wp.views30dPrev || 0),
    users: visitors,
    activeUsers: visitors,
    conversions: 0,
    conversionRate: 0,
    pagesPerSession: 0,
    viewsTrend: wp.viewsTrend || [],
    visitorsTrend: wp.visitorsTrend || [],
    topPages: wp.topPages || [],
    topReferrers: wp.topReferrers || [],
    deviceBreakdown: wp.deviceBreakdown || [],
    dataSource: "Independent Analytics",
    period: wp.period || {}
  };
}
