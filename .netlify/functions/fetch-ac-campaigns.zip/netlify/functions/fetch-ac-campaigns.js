// netlify/functions/fetch-ac-campaigns.js
exports.handler = async () => {
  const base = (process.env.AC_BASE_URL || "").replace(/\/$/, "");
  const apiKey = process.env.AC_API_KEY;
  if (!base || !apiKey) {
    return { statusCode: 503, body: JSON.stringify({ error: "Missing env vars" }) };
  }
  const headers = { "Api-Token": apiKey, "Content-Type": "application/json" };
  try {
    const campRes = await fetch(
      `${base}/api/3/campaigns?filters[status]=5&orders[sdate]=DESC&limit=10`,
      { headers }
    );
    const campData = await campRes.json();
    const campaigns = campData.campaigns || [];
    const debugRes = await fetch(`${base}/api/3/campaigns/${campaigns[0]?.id}`, { headers });
    const debugData = await debugRes.json();
    const withMessages = await Promise.all(campaigns.map(async (c) => {
      try {
        const detailRes = await fetch(`${base}/api/3/campaigns/${c.id}`, { headers });
        const detailData = await detailRes.json();
        const campaign = detailData.campaign || {};
        const msgId = campaign.message_id || campaign.campaign_message_id;
        let messageContent = null;
        if (msgId) {
          const msgRes = await fetch(`${base}/api/3/messages/${msgId}`, { headers });
          const msgData = await msgRes.json();
          const m = msgData.message || {};
          const rawBody = m.body || m.html || m.text || "";
          messageContent = {
            subject: m.subject || "",
            preheader: m.preheader_text || "",
            fields: Object.keys(m).join(", "),
            body: rawBody.replace(/<style[^>]*>[\s\S]*?<\/style>/gi, "").replace(/<script[^>]*>[\s\S]*?<\/script>/gi, "").replace(/<[^>]+>/g, " ").replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/\s+/g, " ").trim().slice(0, 3e3)
          };
        }
        return {
          id: c.id,
          name: c.name,
          sent: (c.sdate || "").slice(0, 10),
          sendamt: c.sendamt,
          uniqueopens: c.uniqueopens,
          subscriberclicks: c.subscriberclicks,
          messageid: msgId,
          message: messageContent
        };
      } catch (e) {
        return { id: c.id, name: c.name, sent: (c.sdate || "").slice(0, 10), message: null, error: e.message };
      }
    }));
    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ debug: debugData, campaigns: withMessages })
    };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};
